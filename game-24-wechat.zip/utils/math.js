'use strict';

/* --- 有理数 --- */
function gcd(a, b) {
  a = Math.abs(a); b = Math.abs(b);
  while (b) { const t = a % b; a = b; b = t; }
  return a || 1;
}
function R(n, d) {
  if (d === undefined) d = 1;
  if (d === 0) return null;
  if (d < 0) { n = -n; d = -d; }
  const g = gcd(n, d);
  return { n: n / g, d: d / g };
}
const rAdd = (a, b) => R(a.n * b.d + b.n * a.d, a.d * b.d);
const rSub = (a, b) => R(a.n * b.d - b.n * a.d, a.d * b.d);
const rMul = (a, b) => R(a.n * b.n, a.d * b.d);
const rDiv = (a, b) => (b.n === 0 ? null : R(a.n * b.d, a.d * b.n));
const rStr = (a) => (a.d === 1 ? String(a.n) : a.n + '/' + a.d);
const rIs = (a, k) => a.d === 1 && a.n === k;

/* --- 表达式求值：tokens = [{t:'num',v:3},{t:'op',v:'+'}...] --- */
/* --- 相连运算符先合并：×÷ 按「÷ 的个数奇偶」翻转，+− 按减号个数翻转 --- */
function collapseRun(syms) {
  let i = 0;
  let mul = null;
  while (i < syms.length && (syms[i] === '×' || syms[i] === '÷')) {
    const s = syms[i++];
    if (mul === null) mul = s;
    else if (s === '÷') mul = mul === '×' ? '÷' : '×';
  }
  if (mul !== null) {
    let sign = 1;
    for (; i < syms.length; i++) {
      const s = syms[i];
      if (s === '-') sign = -sign;
      else if (s !== '+') throw new Error('加减号后面不能直接跟「' + s + '」');
    }
    return { kind: 'mul', op: mul, sign: sign };
  }
  let neg = 0;
  for (; i < syms.length; i++) {
    const s = syms[i];
    if (s === '-') neg++;
    else if (s !== '+') throw new Error('加减号后面不能直接跟「' + s + '」');
  }
  return { kind: 'add', op: neg % 2 ? '-' : '+', sign: 1 };
}

function normalizeTokens(tokens) {
  const out = [];
  for (let i = 0; i < tokens.length; i++) {
    const tk = tokens[i];
    if (tk.t !== 'op') { out.push(tk); continue; }
    const syms = [];
    while (i < tokens.length && tokens[i].t === 'op') { syms.push(tokens[i].v); i++; }
    i--;
    const c = collapseRun(syms);
    out.push({ t: 'op', v: c.op, kind: c.kind, sign: c.sign });
  }
  return out;
}

function evalTokens(tokens, advancedSyntax = true) {
  const list = advancedSyntax ? normalizeTokens(tokens) : tokens.map((token) => {
    if (token.t !== 'op') return token;
    const kind = token.v === '+' || token.v === '-' ? 'add' : 'mul';
    return { ...token, kind, sign: 1 };
  });
  let i = 0;
  const err = (m) => { throw new Error(m); };
  const peek = () => list[i];
  const isOp = (tk, kind) => !!tk && tk.t === 'op' && tk.kind === kind;

  function parseExpr() {
    let v = parseTerm();
    while (isOp(peek(), 'add')) {
      const op = list[i++].v;
      const r = parseTerm();
      v = op === '+' ? rAdd(v, r) : rSub(v, r);
    }
    return v;
  }
  function parseTerm() {
    let v = parseFactor();
    while (isOp(peek(), 'mul')) {
      const tk = list[i++];
      let r = parseFactor();
      if (tk.sign === -1) r = rSub(R(0, 1), r);
      if (tk.v === '×') { v = rMul(v, r); }
      else {
        if (r.n === 0) err('不能除以 0');
        v = rDiv(v, r);
      }
    }
    return v;
  }
  function parseFactor(allowSign = true) {
    const tk = peek();
    if (!tk) err('算式还没写完：末尾缺少数字');
    /* 一串加减号 = 一个正负号：−− 即 +，+− 即 − */
    if (isOp(tk, 'add') && allowSign) {
      i++;
      const v = parseFactor(advancedSyntax);
      return tk.v === '-' ? rSub(R(0, 1), v) : v;
    }
    if (tk.t === 'num') { i++; return R(tk.v, 1); }
    if (tk.t === 'lp') {
      i++;
      const v = parseExpr();
      if (!list[i] || list[i].t !== 'rp') err('括号没配对：少了「)」');
      i++;
      return v;
    }
    if (tk.t === 'rp') err('括号没配对：多了一个「)」');
    if (tk.t === 'op') err('这里需要数字或括号，请检查「' + (tk.v === '-' ? '−' : tk.v) + '」的位置');
    if (tk.t === 'win') err('WIN 牌不能参与计算');
    err('算式不完整');
  }

  const v = parseExpr();
  const tk = list[i];
  if (tk) {
    if (tk.t === 'num' || tk.t === 'lp') err('两个数字之间缺少运算符');
    if (tk.t === 'rp') err('括号没配对：多了一个「)」');
    err('算式不完整');
  }
  return v;
}

/* --- 算式字符串拼接（带最少括号） --- */
const ATOMIC_P = 9;
function catExpr(a, b, op, prec) {
  const disp = op === '-' ? '−' : op;
  const left = a.p < prec ? '(' + a.e + ')' : a.e;
  const needRight = b.p < prec || (b.p === prec && (op === '-' || op === '÷'));
  return left + disp + (needRight ? '(' + b.e + ')' : b.e);
}

/* --- 24 点求解（返回一条算式的字符串，无解返回 null） --- */
function solve24(nums) {
  const start = nums.map((n) => ({ v: R(n, 1), e: String(n), p: ATOMIC_P }));

  function rec(list) {
    if (list.length === 1) {
      const x = list[0].v;
      return rIs(x, 24) ? list[0].e : null;
    }
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const a = list[i], b = list[j];
        const rest = list.filter((_, k) => k !== i && k !== j);
        const cands = [
          { v: rAdd(a.v, b.v), e: catExpr(a, b, '+', 1), p: 1 },
          { v: rSub(a.v, b.v), e: catExpr(a, b, '-', 1), p: 1 },
          { v: rSub(b.v, a.v), e: catExpr(b, a, '-', 1), p: 1 },
          { v: rMul(a.v, b.v), e: catExpr(a, b, '×', 2), p: 2 }
        ];
        if (b.v.n !== 0) cands.push({ v: rDiv(a.v, b.v), e: catExpr(a, b, '÷', 2), p: 2 });
        if (a.v.n !== 0) cands.push({ v: rDiv(b.v, a.v), e: catExpr(b, a, '÷', 2), p: 2 });
        for (let c = 0; c < cands.length; c++) {
          const r = rec(rest.concat([cands[c]]));
          if (r) return r;
        }
      }
    }
    return null;
  }
  return rec(start);
}

/* --- 枚举四张牌能算出的整数结果（限定区间），返回 Map<数值, 算式> --- */
function collectTargets(nums, lo, hi) {
  const found = new Map();
  const start = nums.map((n) => ({ v: R(n, 1), e: String(n), p: ATOMIC_P }));

  function rec(list) {
    if (list.length === 1) {
      const x = list[0].v;
      if (x.d === 1 && x.n >= lo && x.n <= hi && !found.has(x.n)) found.set(x.n, list[0].e);
      return;
    }
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const a = list[i], b = list[j];
        const rest = list.filter((_, k) => k !== i && k !== j);
        const cands = [
          { v: rAdd(a.v, b.v), e: catExpr(a, b, '+', 1), p: 1 },
          { v: rSub(a.v, b.v), e: catExpr(a, b, '-', 1), p: 1 },
          { v: rSub(b.v, a.v), e: catExpr(b, a, '-', 1), p: 1 },
          { v: rMul(a.v, b.v), e: catExpr(a, b, '×', 2), p: 2 }
        ];
        if (b.v.n !== 0) cands.push({ v: rDiv(a.v, b.v), e: catExpr(a, b, '÷', 2), p: 2 });
        if (a.v.n !== 0) cands.push({ v: rDiv(b.v, a.v), e: catExpr(b, a, '÷', 2), p: 2 });
        for (let c = 0; c < cands.length; c++) rec(rest.concat([cands[c]]));
      }
    }
  }
  rec(start);
  return found;
}

module.exports = { evalTokens, solve24, collectTargets, rIs, rStr };
