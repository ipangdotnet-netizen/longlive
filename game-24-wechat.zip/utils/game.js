'use strict';

const { evalTokens, solve24, collectTargets, rIs, rStr } = require('./math');
const DIFFS = {
  easy: { label: '容易', time: 60, min: 8, max: 11, use: 2 },
  hard: { label: '困难', time: 45, min: 7, max: 10, use: 2 },
  hell: { label: '地狱', time: 30, min: 6, max: 9, use: 1 }
};
const SUITS = [
  { suit: '♠', red: false }, { suit: '♥', red: true },
  { suit: '♦', red: true }, { suit: '♣', red: false }
];
const BONUS = {
  plus: { label: '+1', value: 1 },
  minus: { label: '−1', value: -1 },
  win: { label: 'WIN' }
};
const OPS = ['+', '-', '×', '÷'];
const SYMBOLS = OPS.concat(['(', ')']).map(key => ({
  key, label: key === '-' ? '−' : key,
  type: key === '(' ? 'lp' : key === ')' ? 'rp' : 'op'
}));
const BONUS_CAP = 3;
const rankLabel = rank => ({ 1: 'A', 11: 'J', 12: 'Q', 13: 'K' })[rank] || String(rank);

function evaluatorInput(formula) {
  const out = [];
  formula.forEach(piece => {
    if (piece.type !== 'num') {
      out.push(piece.type === 'op' ? { t: 'op', v: piece.op } : { t: piece.type });
      return;
    }
    const last = out[out.length - 1];
    // 奖励牌接在数字或右括号后时是一项加减项，不占符号库存。
    if (piece.bonusId && last && (last.t === 'num' || last.t === 'rp')) out.push({ t: 'op', v: '+' });
    out.push({ t: 'num', v: piece.value });
  });
  return out;
}

class Game {
  constructor(mode, difficulty, random = Math.random) {
    this.classic = mode === 'classic';
    this.difficulty = DIFFS[difficulty] || DIFFS.hard;
    this.random = random;
    this.sequence = 0;
    this.deck = [];
    this.round = 1;
    this.wins = 0;
    this.bonus = [];
    this.dealRound();
  }

  id(prefix) {
    this.sequence++;
    return prefix + this.sequence;
  }

  shuffle(list) {
    for (let i = list.length - 1; i > 0; i--) {
      const j = Math.floor(this.random() * (i + 1));
      const item = list[i];
      list[i] = list[j];
      list[j] = item;
    }
    return list;
  }

  refill() {
    const deck = [];
    SUITS.forEach(suit => {
      for (let rank = 1; rank <= 13; rank++) deck.push({ ...suit, rank });
    });
    this.deck = this.shuffle(deck);
  }

  rollSupply(solution) {
    const stock = { '(': 2, ')': 2, '+': 0, '-': 0, '×': 0, '÷': 0 };
    if (this.classic) {
      OPS.forEach(op => { stock[op] = 3; });
      return stock;
    }
    for (const char of solution) {
      const op = char === '−' ? '-' : char;
      if (OPS.includes(op)) stock[op]++;
    }
    const { min, max } = this.difficulty;
    const total = min + Math.floor(this.random() * (max - min + 1));
    const used = OPS.reduce((count, op) => count + stock[op], 0);
    const slots = [];
    OPS.forEach(op => {
      for (let i = stock[op]; i < 3; i++) slots.push(op);
    });
    this.shuffle(slots).slice(0, total - used).forEach(op => { stock[op]++; });
    return stock;
  }

  dealRound() {
    let cards;
    let solution;
    let target = 24;
    for (let attempt = 0; attempt < 26 && !solution; attempt++) {
      if (this.deck.length < 4) this.refill();
      cards = this.deck.splice(0, 4);
      const ranks = cards.map(item => item.rank);
      if (this.classic) {
        solution = solve24(ranks);
      } else {
        const options = Array.from(collectTargets(ranks, 12, 40));
        if (options.length) [target, solution] = options[Math.floor(this.random() * options.length)];
      }
    }
    if (!solution) {
      cards = [3, 3, 8, 8].map((rank, i) => ({ ...SUITS[i], rank }));
      solution = '8÷(3−8÷3)';
    }
    this.hand = cards.map(card => ({ ...card, id: this.id('c'), label: rankLabel(card.rank) }));
    Object.assign(this, {
      target, solution, stock: this.rollSupply(solution), phase: 'play', formula: [], history: [],
      choice: null, result: null, feedback: '每张牌用一次，算出 ' + target
    });
  }

  remaining(key) {
    const type = key === '(' ? 'lp' : key === ')' ? 'rp' : 'op';
    const used = this.formula.filter(piece => piece.type === type && (type !== 'op' || piece.op === key)).length;
    return this.stock[key] - used;
  }

  get bonusUsed() {
    return this.formula.filter(piece => piece.bonusId).length;
  }

  setFormula(next) {
    if (this.formula.length === next.length && this.formula.every((piece, i) => piece === next[i])) return;
    this.history.push(this.formula);
    this.formula = next;
  }

  edit(kind, key, index) {
    if (this.phase !== 'play') return;
    const next = this.formula.slice();
    if (kind === 'piece') {
      const current = next.findIndex(piece => piece.uid === key);
      if (current < 0) return;
      const [piece] = next.splice(current, 1);
      if (Number.isInteger(index)) next.splice(index > current ? index - 1 : index, 0, piece);
    } else {
      let piece;
      if (kind === 'card') {
        const card = this.hand.find(item => item.id === key);
        if (!card || next.some(item => item.cardId === key)) return;
        piece = { type: 'num', cardId: key, value: card.rank, label: card.label, suit: card.suit, red: card.red, tone: 'number' };
      } else if (kind === 'symbol') {
        const symbol = SYMBOLS.find(item => item.key === key);
        if (!symbol) return;
        if (this.remaining(key) <= 0) return '「' + symbol.label + '」已用完';
        piece = { type: symbol.type, op: key, label: symbol.label, tone: symbol.type === 'op' ? 'operator' : 'paren' };
      } else if (kind === 'bonus') {
        const bonus = this.bonus.find(item => item.id === key);
        if (this.classic || !bonus || next.some(item => item.bonusId === key)) return;
        if (this.bonusUsed >= this.difficulty.use) return '本局最多用 ' + this.difficulty.use + ' 张奖励牌';
        if (bonus.type === 'win' && next.some(item => item.type === 'win')) return '本局只需一张 WIN';
        piece = { type: bonus.type === 'win' ? 'win' : 'num', bonusId: key, ...BONUS[bonus.type], tone: bonus.type };
      } else {
        return;
      }
      const at = Number.isInteger(index) ? Math.max(0, Math.min(index, next.length)) : next.length;
      next.splice(at, 0, { uid: this.id('p'), ...piece });
    }
    this.setFormula(next);
  }

  undo() {
    if (this.phase === 'play' && this.history.length) this.formula = this.history.pop();
  }

  clear() {
    if (this.phase === 'play') this.setFormula([]);
  }

  showResult(good, title, note, solution = '') {
    this.phase = 'result';
    this.choice = null;
    this.result = { good, title, note, solution };
  }

  submit() {
    if (this.phase !== 'play') return;
    if (!this.formula.length) return '算式区还是空的';
    const win = this.formula.find(piece => piece.type === 'win');
    if (win) {
      this.bonus = this.bonus.filter(card => card.id !== win.bonusId);
      this.wins++;
      this.showResult(true, 'WIN！本局直接胜利', 'WIN 牌已打出，本局不发奖励牌。');
      return;
    }

    const used = new Set(this.formula.filter(piece => piece.cardId).map(piece => piece.cardId));
    if (used.size !== 4) return '四张亮牌都要用一次，目前用了 ' + used.size + ' 张';
    let value;
    try {
      value = evalTokens(evaluatorInput(this.formula), !this.classic);
    } catch (error) {
      return error.message;
    }
    if (rIs(value, this.target)) {
      this.correct();
      return;
    }
    const reason = '算得 ' + rStr(value) + '，目标是 ' + this.target;
    if (this.classic) this.feedback = reason + '。可以修改后重试。';
    else this.fail('答错了', reason + '。');
  }

  correct() {
    this.wins++;
    if (this.classic) {
      this.showResult(true, '24 点！本局胜利', '四张牌各用一次，结果正好是 24。');
      return;
    }
    const used = new Set(this.formula.filter(piece => piece.bonusId).map(piece => piece.bonusId));
    this.bonus = this.bonus.filter(card => !used.has(card.id));
    const value = this.random();
    const type = value < 0.4 ? 'plus' : value < 0.8 ? 'minus' : 'win';
    const gain = { id: this.id('b'), type, label: BONUS[type].label };
    if (this.bonus.length < BONUS_CAP) {
      this.bonus.push(gain);
      this.showResult(true, this.target + ' 点！本局胜利', '获得奖励牌「' + gain.label + '」。');
      return;
    }
    this.phase = 'choice';
    this.choice = {
      title: '奖励牌上限 3 张', note: '选择一张要弃掉的牌。', gain,
      pool: this.bonus.concat([{ ...gain, isNew: true }])
    };
  }

  timeout() {
    if (this.phase === 'play') this.fail('超时', '时间到了还没交出算式。');
  }

  fail(title, reason) {
    if (this.classic) {
      this.showResult(false, title, reason, this.solution);
    } else if (!this.bonus.length) {
      this.phase = 'over';
      this.result = { good: false, title: '游戏结束', note: title + '。' + reason + '没有奖励牌可扣。', solution: this.solution };
    } else if (this.bonus.length === 1) {
      const [lost] = this.bonus;
      this.bonus = [];
      this.showResult(false, title + ' · 扣掉「' + lost.label + '」', reason + '这次仍可继续。', this.solution);
    } else {
      this.phase = 'choice';
      this.choice = { title: '扣除一张奖励牌', note: reason + '请选择要弃掉的一张牌。', head: title, reason, pool: this.bonus.slice() };
    }
  }

  pick(id) {
    if (this.phase !== 'choice') return;
    const { pool, gain, head, reason } = this.choice;
    const picked = pool.find(card => card.id === id);
    if (!picked) return;
    this.bonus = pool.filter(card => card.id !== id).map(({ id, type, label }) => ({ id, type, label }));
    if (gain) {
      const note = gain.id === id
        ? '已弃掉新抽到的「' + gain.label + '」，保留原有奖励牌。'
        : '获得新牌「' + gain.label + '」，弃掉旧牌「' + picked.label + '」。';
      this.showResult(true, this.target + ' 点！本局胜利', note);
    } else {
      this.showResult(false, head + ' · 扣掉「' + picked.label + '」', reason, this.solution);
    }
  }

  next() {
    if (this.phase === 'result') {
      this.round++;
      this.dealRound();
    }
  }
}

module.exports = { Game, DIFFS, SYMBOLS };
