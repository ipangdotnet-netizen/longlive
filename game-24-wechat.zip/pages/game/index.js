'use strict';

const { Game, DIFFS, SYMBOLS } = require('../../utils/game');
const DIFFICULTIES = Object.keys(DIFFS).map(key => ({ key, ...DIFFS[key] }));

function slotAt(x, y, area, pieces) {
  if (x < area.left - 12 || x > area.right + 12 || y < area.top - 12 || y > area.bottom + 12) return null;
  if (!pieces.length) {
    return { index: 0, left: area.left + area.width / 2, top: area.top + 12, height: area.height - 24 };
  }

  const rows = [];
  pieces.forEach((rect, index) => {
    const center = (rect.top + rect.bottom) / 2;
    let row = rows[rows.length - 1];
    if (!row || Math.abs(row.center - center) > 4) {
      row = { center, height: 0, items: [] };
      rows.push(row);
    }
    row.items.push({ rect, index });
    row.height = Math.max(row.height, rect.height);
  });
  const row = rows.reduce((nearest, candidate) =>
    Math.abs(candidate.center - y) < Math.abs(nearest.center - y) ? candidate : nearest);
  const at = row.items.findIndex(item => x < item.rect.left + item.rect.width / 2);
  const current = row.items[at];
  const previous = at < 0 ? row.items[row.items.length - 1] : row.items[at - 1];
  let left;
  if (current && previous) left = (previous.rect.right + current.rect.left) / 2;
  else left = current ? current.rect.left - 3 : previous.rect.right + 3;
  return {
    index: current ? current.index : previous.index + 1,
    left, top: row.center - row.height / 2, height: row.height
  };
}

Page({
  data: {
    difficulties: DIFFICULTIES,
    modes: [
      { key: 'advanced', label: '进阶挑战', note: '随机目标 12–40 · 奖励牌' },
      { key: 'classic', label: '经典 24 点', note: '固定目标 24 · 四张亮牌' }
    ],
    panel: 'setup',
    draftMode: 'advanced',
    draftDiff: 'hard',
    settingsReturn: false,
    showRulesDetails: false,
    hasGame: false,
    classic: false,
    active: false,
    phase: '',
    clock: 45,
    progress: 100,
    lowTime: false,
    drag: null,
    caret: null
  },

  onLoad() {
    this._panel = 'setup';
    this._mode = 'advanced';
    this._diff = 'hard';
    this._remaining = 0;
    this._deadline = 0;
  },

  onHide() {
    this.clearTick();
    this.resetDrag(true);
  },

  onShow() {
    if (this._game && this._game.phase === 'play' && !this._panel) {
      this.tick();
      if (this._game.phase === 'play') this.runTick();
    }
  },

  onUnload() {
    this.clearTick();
    this._gesture = null;
  },

  clearTick() {
    if (this._tickId != null) clearInterval(this._tickId);
    this._tickId = null;
  },

  runTick() {
    this.clearTick();
    this._tickId = setInterval(() => this.tick(), 100);
  },

  clockData() {
    const total = this._game.difficulty.time * 1000;
    return {
      clock: Math.ceil(this._remaining / 1000),
      progress: Math.round(this._remaining / total * 100),
      lowTime: this._remaining <= total * 0.25
    };
  },

  tick() {
    if (!this._game || this._game.phase !== 'play' || !this._deadline) return;
    this._remaining = Math.max(0, this._deadline - Date.now());
    if (this._remaining === 0) {
      this._deadline = 0;
      this.clearTick();
      this._game.timeout();
      this.resetDrag(true);
      this.paint();
      return;
    }
    const clock = this.clockData();
    if (clock.clock !== this.data.clock || clock.progress !== this.data.progress) this.setData(clock);
  },

  beginClock() {
    this._remaining = this._game.difficulty.time * 1000;
    this._deadline = Date.now() + this._remaining;
    this.runTick();
  },

  paint() {
    const game = this._game;
    if (!game) return;
    const phase = game.phase;
    if (phase !== 'play') {
      this._deadline = 0;
      this.clearTick();
    }
    const cards = game.hand.map(card => ({
      ...card, used: game.formula.some(piece => piece.cardId === card.id)
    }));
    const bonus = game.bonus.map(card => ({
      ...card, used: game.formula.some(piece => piece.bonusId === card.id)
    }));
    this.setData({
      hasGame: true, classic: game.classic, phase, panel: this._panel,
      active: phase === 'play' && !this._panel,
      modeName: game.classic ? '经典 24 点' : '进阶挑战',
      difficultyName: game.difficulty.label, round: game.round, wins: game.wins, target: game.target,
      cards, bonus, formula: game.formula, feedback: game.feedback,
      symbols: SYMBOLS.map(symbol => ({ ...symbol, count: game.remaining(symbol.key) })),
      bonusUse: game.bonusUsed, bonusMax: game.difficulty.use, canUndo: game.history.length > 0,
      submitLabel: game.formula.some(piece => piece.type === 'win') ? '打出 WIN' : '提交算式',
      choice: game.choice, result: game.result, ...this.clockData()
    });
  },

  selectMode(event) { this.setData({ draftMode: event.currentTarget.dataset.key }); },
  selectDifficulty(event) { this.setData({ draftDiff: event.currentTarget.dataset.key }); },

  startGame() {
    if (this._panel !== 'setup') return;
    this._mode = this.data.draftMode;
    this._diff = this.data.draftDiff;
    this._game = new Game(this._mode, this._diff);
    this._panel = '';
    this.beginClock();
    this.paint();
  },

  openRules() {
    if (!this._game || this._panel || this._game.phase === 'choice' || this._game.phase === 'over') return;
    this.tick();
    if (this._game.phase === 'choice' || this._game.phase === 'over') return;
    this._deadline = 0;
    this.clearTick();
    this.resetDrag(true);
    this._panel = 'rules';
    this.paint();
  },

  closeRules() {
    if (this._panel !== 'rules') return;
    this._panel = '';
    if (this._game.phase === 'play') {
      this._deadline = Date.now() + this._remaining;
      this.runTick();
    }
    this.paint();
  },

  changeSettings() {
    const canReturn = this._panel === 'rules';
    if (!canReturn && this._game.phase !== 'over') return;
    this._panel = 'setup';
    this.setData({
      panel: 'setup', active: false, draftMode: this._mode, draftDiff: this._diff,
      settingsReturn: canReturn, showRulesDetails: false
    });
  },

  backToRules() {
    if (this._panel !== 'setup' || !this.data.settingsReturn) return;
    this._panel = 'rules';
    this.paint();
  },

  toggleDetails() { this.setData({ showRulesDetails: !this.data.showRulesDetails }); },

  allowEdit() {
    if (this._panel || !this._game || this._game.phase !== 'play') return false;
    this.tick();
    return this._game.phase === 'play';
  },

  applyEdit(kind, key, index) {
    if (!this.allowEdit()) return;
    const notice = this._game.edit(kind, key, index);
    if (notice) wx.showToast({ title: notice, icon: 'none' });
    else this.paint();
  },

  tapPiece(event) {
    if (this._blockedTapUntil > Date.now()) return;
    const { kind, key } = event.currentTarget.dataset;
    this.applyEdit(kind, key);
  },

  undo() {
    if (!this.allowEdit()) return;
    this.resetDrag(true);
    this._game.undo();
    this.paint();
  },

  clear() {
    if (!this.allowEdit()) return;
    this.resetDrag(true);
    this._game.clear();
    this.paint();
  },

  submit() {
    if (!this.allowEdit()) return;
    this.resetDrag(true);
    const notice = this._game.submit();
    if (notice) wx.showToast({ title: notice, icon: 'none' });
    else this.paint();
  },

  choose(event) {
    if (this._panel || this._game.phase !== 'choice') return;
    this._game.pick(event.currentTarget.dataset.key);
    this.paint();
  },

  next() {
    if (this._panel || this._game.phase !== 'result') return;
    this._game.next();
    this.beginClock();
    this.paint();
  },

  restart() {
    if (this._panel || this._game.phase !== 'over') return;
    this._game = new Game(this._mode, this._diff);
    this.beginClock();
    this.paint();
  },

  touchStart(event) {
    if (this._gesture || !this.allowEdit()) return;
    const touch = event.changedTouches[0];
    if (!touch) return;
    const { kind, key, label, tone } = event.currentTarget.dataset;
    const gesture = {
      kind, key, label, tone, id: touch.identifier,
      startX: touch.clientX, startY: touch.clientY, moved: false, area: null, pieces: []
    };
    this._gesture = gesture;
    const query = wx.createSelectorQuery();
    query.select('#formula-drop').boundingClientRect();
    query.selectAll('.piece').boundingClientRect();
    query.exec(([area, pieces]) => {
      if (this._gesture !== gesture || !area) return;
      gesture.area = area;
      gesture.pieces = pieces || [];
    });
  },

  touchMove(event) {
    const gesture = this._gesture;
    if (!gesture) return;
    const touch = event.changedTouches.find(item => item.identifier === gesture.id);
    if (!touch) return;
    const x = touch.clientX;
    const y = touch.clientY;
    if (!gesture.moved && Math.hypot(x - gesture.startX, y - gesture.startY) < 8) return;
    gesture.moved = true;
    const caret = gesture.area ? slotAt(x, y, gesture.area, gesture.pieces) : null;
    this.setData({ drag: { left: x, top: y, label: gesture.label, tone: gesture.tone }, caret });
  },

  touchEnd(event) {
    const gesture = this._gesture;
    if (!gesture) return;
    const touch = event.changedTouches.find(item => item.identifier === gesture.id);
    if (!touch) return;
    const moved = gesture.moved;
    this.resetDrag(moved);
    if (!moved || !gesture.area) return;
    const slot = slotAt(touch.clientX, touch.clientY, gesture.area, gesture.pieces);
    if (slot || gesture.kind === 'piece') this.applyEdit(gesture.kind, gesture.key, slot ? slot.index : undefined);
  },

  touchCancel(event) {
    const gesture = this._gesture;
    const touches = event.changedTouches || [];
    if (gesture && (!touches.length || touches.some(item => item.identifier === gesture.id))) this.resetDrag(true);
  },

  resetDrag(suppressTap) {
    if (suppressTap && this._gesture) this._blockedTapUntil = Date.now() + 250;
    this._gesture = null;
    if (this.data.drag || this.data.caret) this.setData({ drag: null, caret: null });
  }
});
